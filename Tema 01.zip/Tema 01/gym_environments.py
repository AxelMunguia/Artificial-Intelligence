from gym import envs #Conocer todos los entornos disponibles
import pandas as pd
#%% Obtener el ID de los environments
env_names = [env.id for env in envs.registry.all()]
#%%
for name in sorted(env_names):
    print(name)
## Los entornos que tienen ram en el nobre del entorno significa que la observación se genera en memoria.
# Si trae deterministic significa que las acciones en el entorno se llevan a cabo por el agente de manera repetida..
# Si trae noframeskip significa que las acciones son llevadadas con respecto al entorno por el agente una vez.
    
env_names= pd.DataFrame(sorted(env_names))
env_names.to_csv('../tema 01/available_environments.csv')
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    