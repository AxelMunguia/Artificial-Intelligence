import gym  # cargamos la librería de OpenAI Gym

#%%
environment = gym.make("MountainCar-v0") # Lanzamos una instancia del videojuego de la Montaña rusa
## Juegos ; [MountainCar-v0,BipedalWalker-v2,SpaceInvaders-v0,Taxi-v2,CartPole-v0]
#%%
environment.reset() # Limpiamos y preparamos el entorno para tomar decisiones
for _ in range(1000): # Durante 2000 iteraciones 
    environment.render() # Pintamos en pantalla la acción del carro en la montaña
    environment.step(environment.action_space.sample()) # Tomamos una decisión aleatoria del conjunto de 
    # las disponibles.
    # Como si el juego tuviese 4 botones nos devolverá una de las 4.
    #next_state -> Object
    #reward     -> Float
    #done       -> Boolean
    #info       -> Dictionary
environment.close() # Cerramos la sesión de Open AI Gym. Para cerrar la ventana emergente que
# aparece y no deje de funcionar python, el núcleo o se congele la pantalla.


## Los entornos que tienen ram en el nobre del entorno significa que la observación se genera en memoria.
# Si trae deterministic significa que las acciones en el entorno se llevan a cabo por el agente de manera repetida..
# Si trae noframeskip significa que las acciones son llevadadas con respecto al entorno por el agente una vez.
