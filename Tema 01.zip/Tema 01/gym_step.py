import gym  # cargamos la librería de OpenAI Gym

#%% Crear entorno y número de episodios
environment = gym.make("BipedalWalker-v2") 
MAX_NUM_EPISODES = 10 # 10 Vidas
MAX_STEPS_PER_EPISODE = 200# Movimientos
# Ahora cada episodio es una partida, por lo tanto, el reset lo hacemos en cada episodio
#%%
for episode in  range(MAX_NUM_EPISODES):
    obs = environment.reset()
    for step in range(MAX_STEPS_PER_EPISODE):
        environment.render()
        action = environment.action_space.sample()
        next_state,reward,done,info= environment.step(action)
        obs=next_state
        
        if done is True:
            print("\n Episodio #{} terminado en {} steps:".format(episode,step+1))
     
environment.close() # Cerramos la sesión de Open AI Gym. Para cerrar la ventana emergente que
