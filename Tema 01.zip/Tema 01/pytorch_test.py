import torch as tt
#%%
t = tt.Tensor(3,3)
print(t)

# conda install pytorch-cpu -c pytorch 
# pip3 install torchvision
# Install PyTorch (CUDA 9.1) using

# conda install pytorch cuda91 -c pytorch 
# pip3 install torchvision