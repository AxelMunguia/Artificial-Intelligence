import gym
from gym.spaces import *
import sys
#%% Exiten 7 espacios donde viven el conjunto de acciones 8

# # Box -> R^n (x1,x2,x3,...,xn), xi [low, high] # Espacio dimensional
# gym.spaces.Box(-10,10, shape=(2,))  # (x,y), -10<x,y<10

# Discrete -> Números enteros entre 0 y n-1, {0,1,2,3,...,n-1}
# gym.spaces.Discrete(5) # {0,1,2,3,4}

#gym.spaces.Dict({
#            "position": gym.spaces.Discrete(3), #{0,1,2}
#            "velocity": gym.spaces.Discrete(2)  #{0,1}
#        })


# Multi Binary -> {T,F}^n (x1,x2,x3,...xn), xi {T,F} # Para valores Booleanos
# gym.spaces.MultiBinary(3)# (x,y,z), x,y,z = T|F

# Multi Discreto -> {a,a+1,a+2..., b}^m
#gym.spaces.MultiDiscrete([-10,10],[0,1])

# Tuple -> Producto de espacios simples
#gym.spaces.Tuple((gym.spaces.Discrete(3), gym.spaces.Discrete(2)))#{0,1,2}x{0,1} # Habrá 6 elementos 00,01,10,11,20,21

# prng -> Random Seed
#%% hacer función de print spaces
def print_spaces(space):
    print(space)
    if isinstance(space,Box): # Comprueba si el space subministrado es de tipo Box
        print("\n Cota inferior {}",space.low)
        print("\n Cota Superior {}",space.high)
        
if __name__=="__main__":
    environment = gym.make(sys.argv[1])  ## El usuario debe llamar al script con el nombre del entorno como parámetro
    print(" Espacio de Estdos")
    print_spaces(environment.observation_space)
    print("Espacio de acciones: ")
    print_spaces(environment.action_space)
    try:
        print("Descripción de las acciones: ",environment.unwrapped.get_action_meanings())
    except AttributeError:
        pass
    
    
# En el ejemplo del carro 
    
# Espacio de observaciones
# Box(2,) -> 2 dimensiones continuas (x,y)

# Cota inferior {} [-1.2  -0.07] -> El espacio va desde -1.2 hasta 0.6 (Espacio)
# Cota Superior {} [0.6  0.07] -> La velocidad va desde -0.7 a 0.7 (Acelerar e ir de reversa)
# Espacio de acciones:
# Discrete(3) -> -1 Ir de reversa / 0 no hacer nada / 1 acelerar

    
    
    
    
    
    
    
    
    
    
    
    