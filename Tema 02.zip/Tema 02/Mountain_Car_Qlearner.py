#%% Importar 
import gym
import numpy as np
# Instalar -> pip install ffmpeg
#%% Mediante la formula de Q_learning -> $$Q_t(s,a)=Q_{t-1}(s,a)+ \alpha \cdot (R(s,a)+ \gamma max_{a} Q((s'),a') - Q_{t-1}(s,a))$$
# Se va a implementar en código


# Qlearner Class

# __init__(self, environment)
# discretize(self,obs) ## No siempre es necesario, pero resuelta útil cuando el espacio de estados es grande y continuo.
# Ejemplo de discretize [-2,2] hay infinitos valores, sin embargo, si lo discretizamos tendríamos 
# [-2,-1],[-1,0],[0,1], [1,2]
# get_action(self,obs)
# learn(self, obs, action, next_obs)


# Para definir la clase Qlearner necesitaremos de ciertos parámetros. Por ejemplo;

# EPSILON_MIN(Valos más pequeño para llevar a cabo el aprendizaje) Vamos aprendiendo mientras el incremento de aprendizaje sea superior a dicho valor.
# MAX_NUM_EPISODES: Número de iteraciones que estemos dispuestos a realizar.
# STEPS_PER_EPISODE: Número de pasos a realizar en cada episodio.
# ALPHA: Ratio de aprendizaje del agente. (Puede variar conforme hagamos más y más iteracioes).
# Gamma: Factor de descuento (Lo que se pierde de un paso a otro para incentivar al gente).
# NUM_DISCRETE_BINS: Número de divisiones de discretizar el espacio de estados continuos.

EPSILON_MIN=0.005
MAX_NUM_EPISODES = 50000
MAX_STEPS_PER_EPISODE = 200
MAX_NUM_STEPS = MAX_NUM_EPISODES*MAX_STEPS_PER_EPISODE
EPSILON_DECAY = 500*EPSILON_MIN/MAX_NUM_STEPS # DECREMENTO EN EL EPSILON DE UN PASO AL SIGUIENTE
ALPHA = 0.5
GAMMA = 0.98
NUM_DISCRETE_BINS = 30


class QLearner(object):
    def __init__(self,environment): # Toma la instancia e inicializa todo lo necesario y guarda esa información en la misma instancia.
        self.obs_shape = environment.observation_space.shape# (2,)
        self.obs_high = environment.observation_space.high # array([0.6 , 0.07], dtype=float32)
        self.obs_low = environment.observation_space.low # array([-1.2 , -0.07], dtype=float32)
        self.obs_bins = NUM_DISCRETE_BINS
        self.bin_width= (self.obs_high- self.obs_low)/self.obs_bins  # array([0.06      , 0.00466667], dtype=float32)
        
                
        
        self.action_shape = environment.action_space.n  # Cuantas acciones puede llevar a cabo # 3
        self.Q = np.zeros((self.obs_bins+1,self.obs_bins+1,self.action_shape)) # Matriz de 31*31*3
        self.alpha=ALPHA
        self.gamma = GAMMA
        self.epsilon=1.0
        
    def discretize(self, obs):
        return tuple(((obs-self.obs_low)/self.bin_width).astype(int))
        
    
    def get_action(self,obs):
        discrete_obs = self.discretize(obs) #Valor discretizado de la observación
        # Selección de la acción en base a Epsilon-Greedy
        if self.epsilon>EPSILON_MIN:
            self.epsilon -= EPSILON_DECAY
        if np.random.random()> self.epsilon: # Con probabilidad 1-epsilon, elegimos la mejor posible.
            return np.argmax(self.Q[discrete_obs])
        else:
            return np.random.choice([a for a in range(self.action_shape)]) # Con probabilidad epsilon, elegimos una al azar
        # Las primeras elecciones serán aleatorias, sin embargo, empezará a tomar la mejor disponible de las 3 decisiones conforme vaya aprendiendo.

 
    def learn(self,obs,action,reward,next_obs):
        discrete_obs = self.discretize(obs)
        discrete_next_obs = self.discretize(next_obs)
        # Cálcular la recompenza de la ecuación  (la de arriba en Latex)
        # td_target = reward+self.gamma*np.max(self.Q[discrete_next_obs])
        #td_error=td_target- self.Q[discrete_obs][action]
        
        # Lo unimos todo en una sola fila
        ## $$Q_t(s,a)=Q_{t-1}(s,a)+ \alpha \cdot (R(s,a)+ \gamma max_{a} Q((s'),a') - Q_{t-1}(s,a))$$
        self.Q[discrete_obs][action] += self.alpha*( reward+self.gamma*np.max(self.Q[discrete_next_obs]) - self.Q[discrete_obs][action]) 

  
        
# Método para entrenar a nuestro agente
    
def train(agent, environment):
    best_reward = -float('inf')
    for episode in range(MAX_NUM_EPISODES):
        done= False
        obs= environment.reset() # Para despertar al agente. Empezar desde 0
        total_reward= 0.0
        while not done:
            action = agent.get_action(obs) # Acción elegida según la ecuación de Qlearning
            next_obs, reward, done, info = environment.step(action) 
            agent.learn(obs, action, reward, next_obs) # Hacer que el agente aprenda en base de la acció que ha tomado
            obs=next_obs
            total_reward += reward
        if total_reward>best_reward:
            best_reward = total_reward
        print("Episodio No. {} con recompenza: {}, mejor recompenza {}, epsilon: {}".format(episode, total_reward, best_reward,agent.epsilon))
    
    environment.close()
    ## De todas las políticas de entrenamiento que hemos obtenido devolvemos la mejor
    return np.argmax(agent.Q, axis=2)

## Método para entrenar a nuestro agente

# Definimos un método para testear al perfomance de nuestro algorítmo

def test(agent, environment,policy):
    done=False
    obs = environment.reset()
    total_reward=0.0
    while not done:
        action=policy[agent.discretize(obs)] # Acción que dictamina la política que hemos entrenado
        next_obs, reward, done, info = environment.step(action)
        obs=next_obs
        total_reward += reward
    return total_reward

## Método para ilustrar y testear el perfomance del agente
if __name__ == "__main__":
    environment=gym.make("MountainCar-v0")
    agent=QLearner(environment)
    learned_policy= train(agent, environment)
    monitor_path= "./monitor_output"
    environment = gym.wrappers.Monitor(environment,monitor_path, force=True)
    for _ in range(1000):
        test(agent,environment, learned_policy)
    environment.close()
        








