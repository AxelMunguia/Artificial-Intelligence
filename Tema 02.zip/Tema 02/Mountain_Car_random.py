import gym
#%% Crear entorno y número de episodios
environment = gym.make("MountainCar-v0") 
MAX_NUM_EPISODES = 10 
MAX_STEPS_PER_EPISODE = 200# Movimientos
# Ahora cada episodio es una partida, por lo tanto, el reset lo hacemos en cada episodio
#%%
for episode in  range(MAX_NUM_EPISODES):
    done = False
    obs = environment.reset()
    total_reward= 0.0 # Variable para guardar la recompensa total de cada episodio
    step=0
    while not done:
        environment.render()
        action= environment.action_space.sample() # Acción aleatoria (-1,0,1) que posteriormente reemplazaremos por la decision de nuestro agente inteligente
        next_state,reward,done,info = environment.step(action)
        total_reward+=reward
        step+=1
        obs = next_state
    print("\n Episodio No. {} finalizado con {} iteraciones recompensa final {}".format(episode,step+1,total_reward))
environment.close() # Cerramos la sesión de Open AI Gym. Para cerrar la ventana emergente que
