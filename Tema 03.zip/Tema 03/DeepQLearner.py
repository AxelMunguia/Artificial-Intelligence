import numpy as np
import torch
import random
import gym
from datetime import datetime
from argparse import ArgumentParser# Para incorporar parámetros
from tensorboardX import SummaryWriter

from libss.perceptron import SLP
from libss.CNN import CNN
from utils.decay_schedule import LinearDecaySchedule
from utils.Experience_Memory import ExperienceMemory, Experience
from utils.params_manager import ParamsManager

import environments.atari as Atari
import environments.utils as env_utils

#%% Parseador de Argumentos
args = ArgumentParser("DeepQLearning") # Inicializar el parseador
args.add_argument("--params_file",help="Path del fichero JSON de parámetros El valor por defecto es parameter.json",
                  default="parameters.json",metavar="PFILE") #ParamsFile
args.add_argument("--env",
                  help="Entorno de ID de Atari disponible en IOpenAI Gym. El valor por defecto será SeaquestNoFrameskip-v4",
                  default="SeaquestNoFrameskip-v4",metavar="ENV")
args.add_argument("--gpu_id",help="ID de la GPU a utilizar, por defecto 0", default=0,type=int,metavar="GPU_ID")
args.add_argument("--test",help="Modo de testing para jugar sin aprender. Por defecto está desactivado",
                  action="store_true",default=False)
args.add_argument("--render",help="Renderiza el entorno en pantalla. Desactivado por defecto",action = "store_true",
                  default=False)
args.add_argument("--record",help="Almacena Videos y Estados del perfomance del agente", action="store_true",default=False)
args.add_argument("--output_dir",help="Directorio para almacenar los outputs. Por defecto = ./trained_modes/results",
                  default = "./trained_models/results")  

#Namespace(env='SeaquestNoFrameskip-v4', gpu_id=0, 
#           output_dir='./trained_models/results', params_file='parameters.json', 
#           record=False, render=False, test=False)
args = args.parse_args()
#%% Parámetros Globales
manager = ParamsManager(args.params_file)
# Ficheros de logs acerca de la configuración de las ejecuciones
summary_file_prefix = manager.get_agent_params()["summary_filename_prefix"]
summary_filename = summary_file_prefix + args.env + datetime.now().strftime("%y-%m-%d-%H-%M")
#%% Summary Writter de TensorbardX
writer = SummaryWriter(summary_filename)

manager.export_agent_params(summary_filename + "/"+"agent_params.json")
manager.export_environment_params(summary_filename + "/"+"environment_params.json")

# Contador global de ejecuciones
global_step_num = 0 # Pasos en global ejecutados
# Habilitar entrenamiento por gráfica o CPU
use_cuda= manager.get_agent_params()["use_cuda"]
device = torch.device("cuda"+args.gpu_id if torch.cuda.is_available() and use_cuda else "cpu")
# Habilitar semilla aleatoria para poder reproducir el experimento a posterior
seed = manager.get_agent_params()["seed"]
torch.manual_seed(seed)
np.random.seed(seed)

if torch.cuda.is_available() and use_cuda:
    torch.cuda.manual_seed_all(seed)
#%%

## Se modificará el Qleaner para utilizar el SLP para representar la función de incremento de
## conocimeinto. Será el perceptrón quien aprenda en lugar de la ecuación de BellMan
class DeepQLearner(object):
    def __init__(self, obs_shape,action_shape,params): # Toma la instancia e inicializa todo lo necesario y guarda esa información en la misma instancia.
        
        self.params = params
        self.gamma = self.params["gamma"]
        self.learning_rate = self.params["learning_rate"]
        self.best_reward_mean = -float("inf")
        self.best_reward = -float("inf")
        self.training_steps_completed = 0
        self.action_shape = action_shape

        
        if len(obs_shape)==1:# Una dimensión del espacio de observaciones.
            self.DQN=SLP
        elif len(obs_shape)==3: # El estado de observaciones es una imagen (RGB)
            self.DQN = CNN
            
            
        self.Q = self.DQN(obs_shape,action_shape,device).to(device) # Quien debe entrenar nuestra red (device)
        # Le pasos los inputs al perceptrón. Todo el espacio de decision
        
        ## Learning Rate (abajo)
        self.Q_optimizer=torch.optim.Adam(self.Q.parameters(),lr=self.learning_rate) # Q.paramets lo hereda de SLP
        
        if self.params["use_target_network"]: # Para estabilizar el aprendizaje del agente ( Actualizar valores de la red neuronal con las últimas n iteraciones)
            self.Q_target = self.DQN(obs_shape,action_shape,device).to(device)

        ### lr = learning Ratio
        self.policy = self.epsilon_greedy_Q  
        self.epsilon_max = self.params["epsilon_max"]
        self.epsilon_min = self.params["epsilon_min"]
        self.epsilon_decay = LinearDecaySchedule(initial_value=self.epsilon_max,
                                                 final_value=self.epsilon_min,
                                                 max_steps=self.params["epsilon_decay_final_step"]) # Programar caída líneal
        self.step_num = 0 # Número de iteración del algorítmo 
        
        self.memory= ExperienceMemory(capacity = int(self.params["experience_memory_size"])) 
                

    def get_action(self,obs):
        obs  = np.array(obs)
        obs = obs/255.0 # Escalados entre 0 y 1 (RGB se entre 0 y 255)
        if len(obs.shape)==3: # Tenemos una imagen
            if obs.shape[2]<obs.shape[0]: #ANCHURAXALTURAXCOLOR -> ColorxAlturaxAnchura
                obs = obs.reshape(obs.shape[2],obs.shape[1],obs.shape[0])
            obs = np.expand_dims(obs,0) # Queda expandida la imagen
            
        return self.policy(obs) # La política que se hubiese decido en base a la información. 
    
    
    def epsilon_greedy_Q(self,obs):
        writer.add_scalar("DQL/epsilon",self.epsilon_decay(self.step_num),self.step_num)
        # Selección de la acción en base a Epsilon-Greedy
        self.step_num +=1 
        if random.random()<self.epsilon_decay(self.step_num) and not self.params["test"]: # El test se pondrá desde consola
            action = random.choice([a for a in range(self.action_shape)]) # Elegimos una acción aleatoria
        else:
           action= np.argmax(self.Q(obs).data.to(torch.device("cpu")).numpy()) 
        
        return action
 
    def learn(self,obs,action,reward,next_obs,done):
        ## Modificamos el método Learn para calcular los gradientes de pérdida con respecto
        ## los pesos del perceptrón y propagar la información hacia atrás y actualizar y optimizar
        ## el flujo y los pesos de la red neuronal para rerepresentar los valores de aprendizaje de modo
        ## que se aproximen a los valores reales.
        if done:
            td_target = reward+0 # Si no acaba el episodio no hay una nueva recompensa.
        else:
            td_target = reward+self.gamma*torch.max(self.Q(next_obs)) # Recompensa más factor gamma * El aprendizaje del perceptrpon
        td_error=torch.nn.functional.mse_loss(self.Q(obs)[action],td_target) #  Función de pérdidas de valores
        self.Q_optimizer.zero_grad() # Gradiente cero
        td_error.backward() # Término de error hacia atrás. Propagación hacia atrás.
        writer.add_scalar("DQL/td_error",td_error.mean(),self.step_num)
        self.Q_optimizer.step() # Indicamos que realice un paso adelante con la información obtenida 
        
    def replay_experience(self,batch_size=None):
        """ 
        Vuelve a jugar usando la experiencia aleatoria almacenada.
        :param batch_size: tamaño de la muestra a tomar de la memoria.
        :return:
        """
        ## 
        batch_size=None
        batch_size = batch_size if batch_size is not None else self.params["replay_batch_size"]
        experience_batch=self.memory.sample(batch_size) # Tomar muestra de la memoria. De la clase Experience
        self.learn_from_batch_experience(experience_batch)
        self.training_steps_completed += 1
    
    def learn_from_batch_experience(self,experiences):
        """ 
        Actualiza la red neuronal profunda en  base a lo aprendido en el conjunto de experiencias anteriores.
        :param experience: fragmento de recuerdos anteriores.
        :return"""
        ## Extiende el método learn e incorpora las experiencias. Si ya pasaste por una situación similar en el pasado
        ## y a superaste de manera éxitosa, el agente retomará aquella acción para superar la acción de la misma manera como
        ## lo hizo en el pasado. 
        
        
        ### El método recibe un conjunto de experiencias y lo que se hace es extraer;
        ## las observaciones, las acciones, las recompensas, las siguientes observacione y el parámetro done en 
        ## en unididades individuales para los subsiguientes cálculos. 
        ## El donebatch significa para cada experiencia si hay o no hay siguiente observación. 
        
        batch_xp =Experience(*zip(*experiences)) # El asterisco hace una referencia.
        obs_batch = np.array(batch_xp.obs)/255.0 # Recuerda que esta en la namedtuple
        action_bacth = np.array(batch_xp.action)
        reward_batch = np.array(batch_xp.reward) # Todas las experiencias de nuestra memoria.
        if self.params["clip_reward"]:
            reward_batch = np.sign(reward_batch)
            # np.sign([1,2,3,4,-5])=array[1,1,1,1,-1]        
        next_obs_bacth = np.array(batch_xp.next_obs)/255.0
        done_bacth = np.array(batch_xp.done)
        
        if self.params["use_target_network"]: # Reposo del aprendizaje
            if self.step_num % self.params["target_network_update_frequency"]==0: # Pasos para saber si se va actualizar. Debe de ser multiplo.
                self.Q_target.load_state_dict(self.Q.state_dict()) # En la red enfocada a actualizar 
                # el target cada 2 mil iteraciones le cargaremos primero el dict de estados de la red neuronal e inmediaamente
                # calcularemos el td_target.
            td_target = torch.tensor(reward_batch + ~done_bacth * \
                                     np.tile(self.gamma, len(next_obs_bacth)) * \
                                     np.array(self.Q_target(next_obs_bacth).detach().max(1)[0].data))
            # La idea es que si usamos el target networl seguiremos actualizando con la formula misma de Q_target(la de abajo)
            # solo que cuando sean 2 mil haremos un volcado para descargar los últimos aprendizajes, para reposar
            # la fase del aprendizaje.
        else:
            ##~done por si hemos o no terminado. Si done es False no done es True. A nivel numérico es 1 y se multiplíca por 1 
            ## todo lo siguiente. Si done es True hemos finalizado no done es Falso y multiplica 0 por todo lo demás. 
                td_target = torch.tensor(reward_batch + ~done_bacth * \
                        np.tile(self.gamma, len(next_obs_bacth)) * \
                        np.array(self.Q(next_obs_bacth).detach().max(1)[0].data))
                    # La barra es para hacer intros en medio de operación
                   # np.title(2,5) = array([2,2,2,2,2])
                   
        td_target = td_target.to(device)
        action_idx = torch.from_numpy(action_bacth).to(device) # lo pasamos a device para que realice las operaciones
        action_idx = torch.tensor(action_idx,dtype=torch.int64) # Lo cambio si no no funciona abajo
        td_error = torch.nn.functional.mse_loss(
                                                self.Q(obs_batch).gather(1,action_idx.view(-1,1)), # Reuno todas las decisiones que aportan en la experiencia pasada para tomar mi decisión
                                                td_target.float().unsqueeze(1))

                
        self.Q_optimizer.zero_grad()
        td_error.mean().backward() # Antes aprendiamos del error y aplicabamos backward. Ahora tomamos todos los valores
        # que influyen de la memoria. Se cálcula la media y se realiza el backward.
        self.Q_optimizer.step()
        
     # Con save y load puedo hacer el entrenamiento por partes (días distintos).  
    def save(self, env_name):
        file_name = self.params["save_dir"]+"DQL_"+env_name+".ptm"
        agent_state = {"Q":self.Q.state_dict(), # Diccionario de estados
                       "best_reward_mean":self.best_reward_mean,
                       "best_reward":self.best_reward}
        torch.save(agent_state,file_name)
        print("Estado del agente guardado en : ",file_name)
    
    def load(self,env_name):
        file_name = self.params["load_dir"]+"DQL_"+env_name+".ptm"    
        agent_state = torch.load(file_name,map_location = lambda storage, loc: storage)
        # Lambda declara variables que pueden tomar cualquier valor en partícular,este storage nos ayuda a referenciar
        # la propia localizacion donde se encuentra el archivo.
        self.Q.load_state_dict(agent_state["Q"])
        self.Q.to(device) # Encargada de hacer las operaciones
        self.best_reward = agent_state["best_reward"]
        print("Cargado el modelo  desde : ", file_name, " que tiene una mejor recompensa media de :",self.best_reward_mean,
              " y una recompensa máxima de :", self.best_reward)
        
        
if __name__=="__main__":
    env_conf = manager.get_environment_params()
    env_conf["env_name"] = args.env
    if args.test:
        env_conf["episodic_life"] = False # Cuando acaba el juego es el fin del episodio en lugar de que se acabe el episodio al final de cada vida
    reward_type = "LIFE" if env_conf["episodic_life"] else "GAME" # Reportar resultado a lo largo de toda la ejecución y sino juego por juego
    
    custom_region_available = False
    for key,value in env_conf["useful_region"].items(): # Del parameters de los que queremos entrenar
        if key in args.env:
            env_conf["useful_region"] = value
            custom_region_available = True
            # Así localizaremos si tenemos una configuración conocida que quiere llevar el usuario
            break
    if custom_region_available is not True:
        env_conf["useful_region"] = env_conf["useful_region"]["Default"] # Nos quedamos con la configuración por defecto
    print("Configuración por defecto:  ", env_conf)
    
    atari_env = False
    for game in Atari.get_games_list(): # De la clase Atari en environments
        if game.replace("_","") in args.env.lower(): # Si el juego coincide o se encuentra dentro de la lista de los argumentos que ha escrito el usuario
            atari_env = True
    if atari_env:
        environment = Atari.make_env(args.env, env_conf) # Para establecer la configuración
    else:
        # Entonces el entorno no es de atari y utilizaremos utils para pasar a la clase de gym
        environment = env_utils.ResizeReshapeFrames(gym.make(args.env))
            
    obs_shape = environment.observation_space.shape
    action_shape = environment.action_space.n # Para el tamaño n
    agent_params = manager.get_agent_params()
    agent_params["test"] = args.test
    agent_params["clip_reward"] = env_conf["clip_reward"] # Lo clono del entorno
    agent = DeepQLearner(obs_shape,action_shape, agent_params) # Agent está declarado como una clase del DeepQLearner
    
    episode_rewards = list()
    previous_checkpoint_mean_ep_rew = agent.best_reward_mean
    num_improved_episodes_before_checkpoint = 0
    
    if agent_params["load_trained_model"]: # SI hay que cargar la información del modelo entrenado previamente
        try:
            agent.load(env_conf["env_name"])
            previous_checkpoint_mean_ep_rew = agent.best_reward_mean
        except FileNotFoundError:
            print("Error: No existe ningun modelo entrenado para este entorno. Empezamos desde 0")
            
    episode = 0 # Episodio para saber en cual vamos
    
    
    while global_step_num < agent_params["max_training_steps"]:
        obs = environment.reset()
        total_reward = 0.0
        done = False
        step = 0
        while not done:
            if env_conf["render"] or args.render:
                environment.render() # Mostrar por pantalla
            
            action = agent.get_action(obs) # Toma una acción
            next_obs, reward, done, info = environment.step(action)
            agent.memory.store(Experience(obs,action,reward, next_obs, done)) # Implementar experiencia en memoria
            
            obs = next_obs
            total_reward+=reward
            step += 1
            global_step_num += 1
            
            if done is True:
                episode += 1
                episode_rewards.append(total_reward)
                
                if total_reward> agent.best_reward:
                    agent.best_reward = total_reward # Nueva mejor recompensa
                    
                if np.mean(episode_rewards)> previous_checkpoint_mean_ep_rew:
                    num_improved_episodes_before_checkpoint +=1
                    
                if num_improved_episodes_before_checkpoint >= agent_params["save_freq"]: # Si ya hemos mejorado más de 50 veces
                    prev_checkpoint_mean_ep_rew = np.mean(episode_rewards)
                    agent.best_reward_mean = np.mean(episode_rewards)
                    agent.save(env_conf["env_name"])
                    num_improved_episodes_before_checkpoint = 0
                    
                print("\n Episode No. {} finalizado con {} iteraciones. Con {} estados: Recompensa = {}, Recompensa media = {:.2f}, mejor recompensa = {}".format(episode,
                      step+1, reward_type,total_reward, np.mean(episode_rewards),agent.best_reward))
                writer.add_scalar("main/ep_reward",total_reward,global_step_num)
                writer.add_scalar("main/mean_ep_reward",np.mean(episode_rewards),global_step_num)
                writer.add_scalar("main/max_ep_reward",agent.best_reward, global_step_num)
                # SI ya hemos jugados dos veces
                # Las primeras son vanales porque no se aprende nada de ellas
                if agent.memory.get_size() >= 2*agent_params["replay_batch_size"] and not args.test:
                    agent.replay_experience() # Memoria temporal
                    
                
                break
            
            
    environment.close()
    writer.close()
            
# Terminal python DeepQLearner.py --env "CartPole-v0","BipedalWalker-v2"
# python DeepQLearner.py --env "CartPole-v0" --test --render
 # atari_py.list_games() los juegos de la atari           
# Para tensorboard -> tensorboard --logdir=logs/ -> http://localhost:6006/
    
            
            

            