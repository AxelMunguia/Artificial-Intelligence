import numpy as np
import torch
from libs.Single_Layer_Perceptron import SLP
from utils.decay_schedule import LinearDecaySchedule
from utils.Experience_Memory import ExperienceMemory, Experience
import random
import gym
#%%
MAX_NUM_EPISODES = 100000
MAX_STEPS_PER_EPISODE = 300
## Se modificará el Qleaner para utilizar el SLP para representar la función de incremento de
## conocimeinto. Será el perceptrón quien aprenda en lugar de la ecuación de BellMan
class SwallowQLearner(object):
    def __init__(self, environment, learning_rate = 0.005, gamma= 0.98): # Toma la instancia e inicializa todo lo necesario y guarda esa información en la misma instancia.
        self.obs_shape = environment.observation_space.shape# (2,)
        
        self.action_shape = environment.action_space.n  # Cuantas acciones puede llevar a cabo # 3
        self.Q = SLP(self.obs_shape, self.action_shape) # Le pasos los inputs al perceptrón. Todo el espacio de decision
        ## Learning Rate (abajo)
        self.Q_optimizer=torch.optim.Adam(self.Q.parameters(),lr=learning_rate) # Q.paramets lo hereda de SLP
        ### lr = learning Ratio
        self.gamma = gamma
        self.epsilon=1.0
        self.epsilon_max=1.0
        self.epsilon_min=0.05
        self.epsilon_decay = LinearDecaySchedule(initial_value=self.epsilon_max,
                                                 final_value=self.epsilon_min,
                                                 max_steps=0.5*MAX_NUM_EPISODES*MAX_STEPS_PER_EPISODE) # Programar caída líneal
        self.step_num = 0 # Número de iteración del algorítmo 
        self.policy=self.epsilon_greedy_Q        
        self.memory= ExperienceMemory(capacity = int(1e5)) 
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu") # Cuda puede ser más rápido
        

    def get_action(self,obs):
        # También tenemos que modificar el método get_action para utilizar los valores de aprendizaje Q
        # a través de la red neuronal para tomar la decisión final.
        return self.policy(obs) # La política que se hubiese decido en base a la información. 
    
    
    def epsilon_greedy_Q(self,obs):
        # Selección de la acción en base a Epsilon-Greedy
        if random.random()<self.epsilon_decay(self.step_num):
            action = random.choice([a for a in range(self.action_shape)]) # Elegimos una acción aleatoria
        else:
           action= np.argmax(self.Q(obs).data.to(torch.device("cpu")).numpy()) 
        
        return action
 
    def learn(self,obs,action,reward,next_obs):
        ## Modificamos el método Learn para calcular los gradientes de pérdida con respecto
        ## los pesos del perceptrón y propagar la información hacia atrás y actualizar y optimizar
        ## el flujo y los pesos de la red neuronal para rerepresentar los valores de aprendizaje de modo
        ## que se aproximen a los valores reales.
        td_target = reward+self.gamma*torch.max(self.Q(next_obs)) # Recompensa más factor gamma * El aprendizaje del perceptrpon
        td_error=torch.nn.functional.mse_loss(self.Q(obs)[action],td_target) #  Función de pérdidas de valores
        self.Q_optimizer.zero_grad() # Gradiente cero
        td_error.backward() # Término de error hacia atrás. Propagación hacia atrás.
        self.Q_optimizer.step() # Indicamos que realice un paso adelante con la información obtenida 
        
    def replay_experience(self,batch_size):
        """ 
        Vuelve a jugar usando la experiencia aleatoria almacenada.
        :param batch_size: tamaño de la muestra a tomar de la memoria.
        :return:
        """
        ## 
        experience_batch=self.memory.sample(batch_size) # Tomar muestra de la memoria. De la clase Experience
        self.learn_from_batch_experience(experience_batch)
    
    def learn_from_batch_experience(self,experiences):
        """ 
        Actualiza la red neuronal profunda en  base a lo aprendido en el conjunto de experiencias anteriores.
        :param experience: fragmento de recuerdos anteriores.
        :return"""
        ## Extiende el método learn e incorpora las experiencias. Si ya pasaste por una situación similar en el pasado
        ## y a superaste de manera éxitosa, el agente retomará aquella acción para superar la acción de la misma manera como
        ## lo hizo en el pasado. 
        
        
        ### El método recibe un conjunto de experiencias y lo que se hace es extraer;
        ## las observaciones, las acciones, las recompensas, las siguientes observacione y el parámetro done en 
        ## en unididades individuales para los subsiguientes cálculos. 
        ## El donebatch significa para cada experiencia si hay o no hay siguiente observación. 
        
        batch_xp =Experience(*zip(*experiences)) # El asterisco hace una referencia.
        obs_batch = np.array(batch_xp.obs) # Recuerda que esta en la namedtuple
        action_bacth = np.array(batch_xp.action)
        reward_batch = np.array(batch_xp.reward) # Todas las experiencias de nuestra memoria.
        next_obs_bacth = np.array(batch_xp.next_obs)
        done_bacth = np.array(batch_xp.done)
        ##~done por si hemos o no terminado. Si done es False no done es True. A nivel numérico es 1 y se multiplíca por 1 
        ## todo lo siguiente. Si done es True hemos finalizado no done es Falso y multiplica 0 por todo lo demás. 
        td_target = torch.tensor(reward_batch + ~done_bacth * \
                    np.tile(self.gamma, len(next_obs_bacth)) * \
                    np.array(self.Q(next_obs_bacth).detach().max(1)[0].data))
                    # La barra es para hacer intros en medio de operación
                   # np.title(2,5) = array([2,2,2,2,2])
        td_target = td_target.to(self.device)
        action_idx = torch.from_numpy(action_bacth).to(self.device) # lo pasamos a device para que realice las operaciones
        action_idx = torch.tensor(action_idx,dtype=torch.int64) # Lo cambio si no no funciona abajo
        td_error = torch.nn.functional.mse_loss(
                                                self.Q(obs_batch).gather(1,action_idx.view(-1,1)), # Reuno todas las decisiones que aportan en la experiencia pasada para tomar mi decisión
                                                td_target.float().unsqueeze(1))

                
        self.Q_optimizer.zero_grad()
        td_error.mean().backward() # Antes aprendiamos del error y aplicabamos backward. Ahora tomamos todos los valores
        # que influyen de la memoria. Se cálcula la media y se realiza el backward.
        self.Q_optimizer.step()
if __name__=="__main__":
    environment=gym.make("CartPole-v0")
    agent = SwallowQLearner(environment)
    first_episode = True
    episode_rewards=list()
    for episode in range(MAX_NUM_EPISODES):
        obs = environment.reset()
        total_reward = 0.0
        for step in range(MAX_STEPS_PER_EPISODE):
            # environment.render() # Si lo deseas ver en pantalla
            action = agent.get_action(obs)
            next_obs,reward,done,info = environment.step(action)
            agent.memory.store(Experience(obs,action,reward,next_obs,done))
            agent.learn(obs,action,reward,next_obs) # Aprende de la acción pasada, de la nueva, del premio y la siguiente acción
            
            obs = next_obs
            total_reward+=reward
            
            if done==True:
                if first_episode:
                    max_reward = total_reward
                    first_episode = False
                episode_rewards.append(total_reward)
                if total_reward>max_reward:
                    max_reward=total_reward # Para conocer la mejor recompensa hasta el momento
                print("\Episodio {}, finalizado con {} iteraciones, recompensa = {}, recompensa media = {}, mejor recompensa = {}".format(episode,
                      step + 1, total_reward, np.mean(episode_rewards),max_reward))
                if agent.memory.get_size()>100: # Aquí se re-juega con la experiencia
                    agent.replay_experience(32) # 32 Experiencias previas aleatorias mejorar el proceso de aprendizaje.
                break
    environment.close()
            

            
            
            
    
    