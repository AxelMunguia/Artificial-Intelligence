import gym 
import atari_py
import numpy as np
import random
import cv2
from collections import deque
from gym.spaces.box import Box
#%%
def get_games_list():
    return atari_py.list_games()

def make_env(envd_id,env_conf):
    
    ## Configurar todo el entorno.
    
    env = gym.make(envd_id)
    if "NoFrameskip" in env_id:
        assert "NoFrameskip" in env.spec.id
        env = NoopResetEnv(env,noop_max=30) 
        env= MaxAndSkipEnv(env,skip = env_conf["skip_rate"]) # Repite una acción tantas veces.
        
    if env_conf["episodic_life"]: # Sirve para marcar el fin de vida cuando se acaba el episodio
        env = EpisodicLifeEnv(env)
        
    try: 
        if "FIRE" in env.unwrapped.get_action_meanings():   
             env = FireResertenv(env) # Disparar una acción en el reset
    except AttributeError:
        pass
    
    env = AtariRescale(env,env_conf["useful_region"]) # Reescalar a escala de Grises
    
    if env_conf["normalize_observation"]:
        env = NormalizeEnv(env)
        
        
    env = FrameStack(env,env_conf["num_frames_to_stack"])
    
    if env_conf["clip_reward"]:
        env = ClipReward(env)
        
    return env
    
    
def process_frame_84(frame,conf): 
    # Procesa los frames para transformarlos en 84x84, pero ¿Por qué?
    # El entorno de Atari produce observaciones de forma 210x160x3. Esto se representa en un espacio RGB
    # Esto tiene mucho más pixeles e información de la se es capaz de procesar. Tantos pixéles posiblemente no aportan
    # más información que si se reducen. Se reducen para procesar más rápido.
    frame = frame[["crop1"]:conf["crop2"]+160,:160] # De la imagen original a más omenos 160x160.
    frame = frame.mean(2) # Hacemos el promedio y solo se procesa un canal de color en lugar de 3.
    frame = frame.astype(np.float32)
    frame*= 1.0/255.0 # Queda escalado
    frame = cv2.resize(frame,(84,conf["dimension2"])) # Se submuestrea y se reescala a pequeño (84x84)
    frame = cv2.resize(frame,(84,84)) 
    frame = np.reshape(frame,[1,84,84])
    
class AtariRescale(gym.ObservationWrapper): # Clase que se encarga de hacer el reescalado
    def __init__(self,env,enf_conf):
        gym.ObservationWrapper.__init__(self,env)
        self.observation_space = Box(0.0,255,[1,84,84],dtype=np.uint8) # Escalado y se pasa a dimensión [1,84,84]
        self.conf = env_conf
    def observation(self,observation):
        return process_frame_84(observation,self.conf)
    
class NormalizedEnv(gym.ObservationWrapper):
    
    def __init__(self, env = None):
        
        gym.observationWrapper.__init__(self,env)
        self.mean  = 0
        self.std = 0
        self.alpha = .9999
        self.num_steps = 0
    def observation(self, observation):
        self.num_steps+=1
        self.mean = self.mean*self.alpha + observation.mean()*(1-self.alpha) # Media ponderada entre un .9999 de las medias anteriores más la actual que contribuye un .0001
        self.std = self.std*self.alpha + observation.alpha()*(1-self.alpha)
        
        unbiased_mean = self.mean/(1-pow(self.alpha,self.num_steps)) # Me da un valor de la media sin sesgo (Desviación)
        unbiased_std = self.std/(1-pow(self.alpha,self.num_steps))

        return (observation- unbiased_mean)/(unbiased_std+1e-08) # Normalizado le sumamos el 1e-08 para que no pete
    
    
class ClipReward(gym.RewardWrapper): 
    # Diferentes entornos generan distintas recompenzas.
    def __init__(self,env):
        gym.RewardWrapper.__init__(self,env)
        
    def reward(self, reward):
        return np.sign(reward) # Cortar la recompenza -1,0,1. No sirve si la recompenza es de distintas magnitudes
    
class NoopResetEnv(gym.Wrapper):
      ### Tiene lugar cuando se resetea el entorno la gente normalmente empieza en el mismo punto y se recibe la misma observación
      ### El agente se podría acostumbrar a ese estado inicial en cada nivel y podría ser negativo en el momento que empiece en un punto distinto.
      ###  Por lo mismo randomizar el estado iniciar ayuda mucho, pues el agente aprende a decidir en base a la primera casilla en que se encuentre.      
    def __init__(self, env, noop_max = 30): # Noop_max es el número de acciones que realiza antes de devolver un resultado
        gym.Wrapper.__init__(self,env)
        self.noop_max = noop_max
        self.noop_action = 0  # Para llevar un tracking
        assert env.unwrapped.get_action_meanings()[0] == "NOOP" # La condición para seguir adelante es que el entorno
        # tenga la disposición NOOP (No operation action). Que exista una opción programada por el developer que se encargue de no llevar 
        # a cabo ninguna acción contra el entorno (esté quieto), EL entorno se procese, pero el personaje no tome acciones con resultados.
          
    def reset(self):
      self.env.reset()
      noops = random.randrange(0,self.noop_max+1) 
      assert noops>0
      observation = None
      for _ in range(noops):
          observation, _, done, _  = self.env.step(self.noop_action) # Sin llevar a cabo ninguna acción (se salta las primeras noops tiradas)
      return observation
          
    def step(self,action):
      return self.env.step(action)

class FireResetEnv(gym.Wrapper): # Botón de Inicio 
    def __init__(self, env):
        gym.Wrapper.__init__(self,env)
        assert env.unwrapped.get_action_meanings()[1] == "FIRE"
        assert len(env.unwrapped.get_action_meanings()) >= 3 # Para saber que es un botón de inicio de la partida y no una acción del juego
        
    def reset(self):
        # O bien el step 1 o el step 2 llevarán a cabo la acción
        self.env.reset()
        obs,_,done,_ = self.env.step(1) # Que lleve a cabo el  step No. 1
        if done:
            self.env.reset()
        obs,_,done,_ = self.env.step(2) # Que lleve a cabo el  step No. 2
        if done:
            self.env.reset()
        return obs
    
    def step(self,action): # Se sobreescribirá sin problema.
        return self.env.step(action)
    
    
class EpisodicLifeEnv(gym.Wrapper):
    # Solo se reseteará si hay un game over y no si se pierde solo una vida.
    def __init__(self, env):
        gym.Wrapper.__init__(self,env)
        self.lives = 0
        self.has_really_died = False
        
    def step(self, action):
        obs,reward,done,info = self.env.step(action) # Que lleve a cabo el  step "Action"
        self.has_really_died = False
        lives = info['ale.lives']
        if lives< self.lives and libes>0: # Si me quedan menos vidas que las actuales hemos terminado.
            done = True # Cuando terminan las vidas game over
            self.has_really_died = True
        self.lives = lives 
        
        return obs,reward,done, info
    
    def reset(self): # Solo se ejecuta cuando las vidas se acabaron.
        if self.has_really_died is False:
            obs = self.env.reset()
            self.lives = 0
        else: 
            obs,_,_,info = self.envs.step(0) # Me quedo con la acción que no aporta movimiento
            self.lives = info['ale.lives']
            
        return obs
            
    
class MaxAndSkipEnv(gym.Wrapper): 
    
    def __init__(self, env=None,skip = 4): # env = None porque viene de serie (me lo habrán dado)
        # Me va a devolver el cuarto frame (se saltará 3 )
        gym.Wrapper.__init__(self, env)
        self._obs_buffer =  deque(maxlen=2) # Se irán encolando los frames que no quiero procesar
        self._skip = skip
        
    def step(self,action): 
        total_reward = 0.0
        done = None
        for _ in range(self._skip):
             # Este bucle acelera el proceso de aprendizaje (hace tantos pasos del algorítmo como indique la variable skip 
             #y al final de la misma devuelve la mejor de todas las observaciones, la recompensa el parámetro done, info)
            obs, reward, done, info = self.env.step(action)
            self._obs_buffer.append(obs)
            total_reward += reward
            if done:
                break
        max_frame = np.max(np.stack(self._obs_buffer),axis=0)
        
        return max_frame, total_reward, done, info
    
    def reset(self): # limpiar el buffer
        
        self._obs_buffer.clear()
        obs  = self.env.reset()
        self._obs_buffer.append(obs)
        
        return obs
    
class FrameStack(gym.Wrapper):  # Apilar los últimos k-frames
    def __init__(self, env,k):
        gym.Wrapper.__init__(self, env)
        self.k  = k
        self.frames = deque([], maxlen=k)
        shape = env.observation_space.shape # No ponemos self porque es una variable local (del init)
        self.observation_space = Box(low=0,high=255, shape = (shape[0]*k, shape[1],shape[2]), dtype = np.uint8)
        # shape[0]*k para almacenar tantos canales por de color
            
        
    def reset(self):
        obs = self.env.reset()
        for _ in range(self.k):
            self.frames.append(obs)
            # Se inicializa con k copias de la primera observación
        return self.get_obs()
            
    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self.frames.append(obs)
        
        return self.get_obs(), reward, done, info
    
    def get_obs(self):
        assert len(self.frames)==self.k # Si no son iguales no tiene sentido

        return LazyFrames(lsit(self.frames))
    
class LazyFrames(object): # Hereda de la clase object
    
    def __init__(self,frames):
        self.frames = frames
        self.out = None
        
        
    def _force(self):
        
        if self.out is None: # Si todavía no ha sido configurado la variable out
            # Si nadie ha configurado la varibale de la salida concatenamos todos los frames y vacíamos 
            # el volcado de frames. Jamás tendremos más de k frames en memoria.
            self.out = np.concatenate(self.frames,axis=0)
            self.frames = None # Vacíamos la memoria intermedia
            
        return self.out # SI ya ha sido configurado la devuelve
    
    def __array__(self, dtype=None):
        out = self._force()
        if dtype is not None:
            out = out.astype(dtype)
        
        return out
    
    def __len__(self):
        
        return len(self._force())
    
    def __getitem__(self,i):
        
        return self._force()[i]
        
    
            
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    