import gym 
import cv2
import numpy as np
 
class ResizeReshapeFrames(gym.ObservationWrapper): # Hereda de gym.ObservationWrapper
    def __init__(self,environment):
        super(ResizeReshapeFrames, self).__init__(environment)
        if len(self.observation_space.shape)==3:
            self.desired_width = 84
            self.desired_height = 84
            self.desired_chanels = self.observation_space.shape[2]
            # La imagen en C X H X W
            self.observation_space = gym.spaces.Box(0,255,(self.desired_chanels,self.desired_height,self.desired_width),dtype=np.uint8)
            # np.uint8  toman como valor más pequeño 0 y más grande 255
            
    def observation(self,obs):
        # Clase para reescalar imagenes si vienen mal dadas (si vienen giradas por alguna razón)
        if len(obs.shape)==3:
            obs = cv2.resize(obs,(self.desired_width, self.desired_height))
            if obs.shape[2]<obs.shape[0]:
                obs = np.reshape(obs, obs.shape[2],obs.shape[1], obs.shape[0])
        
        return obs
            