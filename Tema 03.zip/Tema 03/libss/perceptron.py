#%% Import 
import torch


class SLP(torch.nn.Module):
    """
    SLP significa Single Layer Perceptron o neurona de una sola capa para aproximar funciones
    """
    
    def __init__(self, input_shape, output_shape, device = torch.device("cpu")):
    
        """:param unput_shape: Tamaño o forma de los datos de entrada.
           :param output_shaoe: Tamaño o forma de los datos de salida.
           :param device: Dispositivo["cpu" p "cuda"] que SLP debe de utilizar para almacenar los inputs a cada iteración"""
           
           ## Siempre que tenemos una clase y esta hereda de otra (LSP hereda de pytorch.nn.Module)
           ## Debemos inciar con una llamada a la súper clase.
        super(SLP, self).__init__()
           
        self.device=device
        self.input_shape=input_shape[0]
        self.hidden_shape=40 # Se definen 40 unidades dentro del perceptrón
        self.linear1 = torch.nn.Linear(self.input_shape, self.hidden_shape)
        ### la clase SLP implementa un perceptrón neuronal de una sola capa. En este caso
        ### el linear1 representa desde los datos de entrada hasta la capa oculta que tiene 40 unidades.
        self.out=torch.nn.Linear(self.hidden_shape, output_shape)


    def forward(self,x):
        x =torch.from_numpy(x).float().to(self.device) # Aplicamos una conver. de array a float y se mapea en el device indicado.
        x = torch.nn.functional.relu(self.linear1(x))  # Función de Activación  RElU. Si aplica si resulta en un número positivo
        x = self.out(x)
        return(x)