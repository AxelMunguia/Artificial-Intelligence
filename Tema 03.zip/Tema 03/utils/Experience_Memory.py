## Está utilidad será para que la neurona ingrese a la memoria de la experiencia y aprenda


from collections import namedtuple
import random

Experience = namedtuple("Experience",["obs","action","reward","next_obs","done"])

#%% Crear clase
class ExperienceMemory(object):
        """ 
        Buffer que simula la experiencia del agente (Memoria)
        """
    
        def __init__(self,capacity = int(1e6)):
            """ 100 mil experiencias.
            :param capacity: Capacidad total de la memoria cíclica, es decir, número máximo de experiencias almacenables
            :return: 
            """
            self.capacity = capacity
            self.memory_idx = 0 # Identificador que sabe la experiencia actual
            self.memory = []
            
                   
        def sample(self,batch_size):
            """
            :param batch_size: Es el tamaño de la memoria a recuperar.
            :return: DEevolvemos una muestra aleatoria de tamaño batch_size de experiencia de la memoria
            """
            assert batch_size<=self.get_size(), " El tamaño de la muestra es superior a la memoria disponible"
            return random.sample(self.memory, batch_size)
    
        def get_size(self):
            """:return: No. Experiencias almacenadas en Memoria"""
            return len(self.memory)
        
        def store(self,exp):
            """:param experience: Objeto experiencia a ser almacenada en memoria"""
            self.memory.insert(self.memory_idx % self.capacity, exp) # 10%10=0 En la posición 0, 11%10=1 En la posición 1
            self.memory_idx += 1
    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
    
    
    
    
    
    