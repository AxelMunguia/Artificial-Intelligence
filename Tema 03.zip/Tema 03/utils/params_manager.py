import json

class ParamsManager(object): # Si no hereda nada será de la clase object
    """ La clase manejará los parámetros de carga"""
    
    def __init__(self,params_file):
        # Se cargarán parámetros del fichero específicado
        self.params = json.load(open(params_file,"r"))
        
    def get_params(self):
        return self.params
    
    def get_agent_params(self):
        return self.params["agent"]
    
    def get_environment_params(self):
        return self.params["environment"]
    
    def update_agent_params(self,**kwargs): # Actualizar los valores
        for key, value in kwargs.items():
            if key in self.get_agent_params().keys():
                self.params["agent"][key]=value

    def export_agent_params(self,file_name):
        with open(file_name,"w") as f:
            json.dump(self.params["agent"],f,indent=4, separators=(",",":"),sort_keys=True) # Para escribir
            # Cada indentación sera 4 espacios en blanco. Separaremos los clave-valor por puntos y las nuevas líneas por coma
            f.write("\n")
            
    def export_environment_params(self,file_name):
        with open(file_name,"w") as f:
            json.dump(self.params["environment"],f,indent=4, separators=(",",":"),sort_keys=True) # Para escribir
            # Cada indentación sera 4 espacios en blanco. Separaremos los clave-valor por puntos y las nuevas líneas por coma
            f.write("\n")


if __name__=="__main__":
    print("Probando Nuestro Manager de Parámetros...")
    param_file = "../parameters.json"
    manager = ParamsManager(param_file)
    agent_params = manager.get_agent_params()
    print("Los parámetros del agente son : ")
    for key, value in agent_params.items():
        print(key,": ",value)
        
    env_params = manager.get_environment_params()
    print("Los parámetros del entorno son : ")
    for key, value in env_params.items():
        print(key,": ",value)
            
    manager.update_agent_params(learning_rate=0.01,gamma=0.92)
    agent_params_updated = manager.get_agent_params()
    print("Los parámetros del agente actualizados son : ")
    for key, value in agent_params.items():
        print(key,": ",value)
    print("Fin de la prueba")

    